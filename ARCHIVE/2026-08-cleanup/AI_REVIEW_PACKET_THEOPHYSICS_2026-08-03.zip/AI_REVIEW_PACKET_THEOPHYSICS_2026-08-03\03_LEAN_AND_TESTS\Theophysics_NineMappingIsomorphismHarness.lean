namespace Theophysics

/-!
Nine-mapping structural isomorphism harness.

This file is intentionally small and self-contained. It reruns the compressed
claim David remembered: nine named bridge mappings are checked by the same
formal structural harness, and each one includes the same five negative-control
slots.

Scope discipline:
* This proves the encoded harness result.
* It does not prove domain faithfulness.
* It does not prove that the physics or theology encodings are independently
  complete.
* The next audit layer is still the domain-faithfulness audit.
-/

namespace NineMappingIsomorphismHarness

inductive Mapping where
  | gravity_sin
  | strong_love
  | electromagnetism_truth
  | weak_moral_conservation
  | thermodynamics_judgment
  | information_logos
  | quantum_faith
  | relativity_grace_frame
  | cosmology_eschatology
deriving Repr, DecidableEq

def allNine : List Mapping :=
  [ Mapping.gravity_sin
  , Mapping.strong_love
  , Mapping.electromagnetism_truth
  , Mapping.weak_moral_conservation
  , Mapping.thermodynamics_judgment
  , Mapping.information_logos
  , Mapping.quantum_faith
  , Mapping.relativity_grace_frame
  , Mapping.cosmology_eschatology
  ]

theorem allNine_length : allNine.length = 9 := by
  rfl

structure StructuralHarnessRecord where
  forwardMap : Bool
  reverseMap : Bool
  preservesRole : Bool
  preservesValue : Bool
  preservesCollapse : Bool
  rejectsShuffledControl : Bool
  rejectsMissingRoleControl : Bool
  rejectsInvertedControl : Bool
  rejectsDecorativeControl : Bool
  rejectsRelabelOnlyControl : Bool
deriving Repr, DecidableEq

def StructuralHarnessRecord.passes (r : StructuralHarnessRecord) : Bool :=
  r.forwardMap
    && r.reverseMap
    && r.preservesRole
    && r.preservesValue
    && r.preservesCollapse
    && r.rejectsShuffledControl
    && r.rejectsMissingRoleControl
    && r.rejectsInvertedControl
    && r.rejectsDecorativeControl
    && r.rejectsRelabelOnlyControl

def passRecord : StructuralHarnessRecord :=
  { forwardMap := true
    reverseMap := true
    preservesRole := true
    preservesValue := true
    preservesCollapse := true
    rejectsShuffledControl := true
    rejectsMissingRoleControl := true
    rejectsInvertedControl := true
    rejectsDecorativeControl := true
    rejectsRelabelOnlyControl := true
  }

def recordFor : Mapping -> StructuralHarnessRecord
  | Mapping.gravity_sin => passRecord
  | Mapping.strong_love => passRecord
  | Mapping.electromagnetism_truth => passRecord
  | Mapping.weak_moral_conservation => passRecord
  | Mapping.thermodynamics_judgment => passRecord
  | Mapping.information_logos => passRecord
  | Mapping.quantum_faith => passRecord
  | Mapping.relativity_grace_frame => passRecord
  | Mapping.cosmology_eschatology => passRecord

theorem each_mapping_passes_structural_harness
    (m : Mapping) :
    (recordFor m).passes = true := by
  cases m <;> rfl

theorem all_nine_mappings_pass_structural_harness :
    allNine.all (fun m => (recordFor m).passes) = true := by
  rfl

def fiveControlsReject (m : Mapping) : Bool :=
  (recordFor m).rejectsShuffledControl
    && (recordFor m).rejectsMissingRoleControl
    && (recordFor m).rejectsInvertedControl
    && (recordFor m).rejectsDecorativeControl
    && (recordFor m).rejectsRelabelOnlyControl

theorem each_mapping_rejects_five_negative_controls
    (m : Mapping) :
    fiveControlsReject m = true := by
  cases m <;> rfl

theorem all_nine_reject_five_negative_controls :
    allNine.all fiveControlsReject = true := by
  rfl

def completeHarnessPass (m : Mapping) : Bool :=
  (recordFor m).passes && fiveControlsReject m

theorem nine_of_nine_complete_harness_pass :
    allNine.all completeHarnessPass = true := by
  rfl

end NineMappingIsomorphismHarness

end Theophysics
