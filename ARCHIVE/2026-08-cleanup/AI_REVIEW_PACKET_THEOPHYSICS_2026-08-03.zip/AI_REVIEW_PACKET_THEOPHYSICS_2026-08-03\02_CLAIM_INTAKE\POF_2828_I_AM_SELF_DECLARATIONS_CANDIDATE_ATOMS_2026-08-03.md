# POF 2828 I AM Self-Declarations Candidate Atoms

Generated: 2026-08-03

Source:

`C:\Users\David\.codex\attachments\b95ba002-3b66-4c6b-a394-428c506607eb\pasted-text.txt`

Status:

Intake only. These are not yet promoted Lane 4 atoms. Each candidate still needs deduplication, source anchoring, negative guards, and proof-class assignment before ledger insertion.

## Intake Summary

- Existing validated Lane 4 atoms: 268
- New candidate atoms from this one document: 34
- Main lane: theology / derivation grammar / logos / Christ interface
- Recommended proof class: framework guardrail, bridge declared, textual-structural claim, or adversarial test candidate

## Candidate Atoms

| ID | Domain | Candidate Claim | Class | First Negative Guard |
|---|---|---|---|---|
| POF2828-001 | root-self-declaration | God self-declaration is treated as root speech, not observer-assembled evidence. | framework_guardrail | Reject if the framework requires creature recognition before divine identity can be named. |
| POF2828-002 | root-self-declaration | The ground publishes identity before creatures can name the ground correctly. | framework_guardrail | Reject if self-declaration is reduced to later human inference. |
| POF2828-003 | covenant-order | In Exodus 20:2, identity precedes command. | textual_structural_claim | Reject if law is treated as prior to divine naming in the covenant sequence. |
| POF2828-004 | covenant-order | Covenant life begins with named divine identity rather than bare obligation. | bridge_declared | Reject if covenant is modeled as command without identity-source. |
| POF2828-005 | old-testament-root | Old Testament I AM declarations cluster around identity, authority, covenant, uniqueness, deliverance, protection, judgment, and holiness. | textual_structural_claim | Reject if the cluster cannot be textually supported across the cited examples. |
| POF2828-006 | old-testament-root | The Old Testament publishes the divine name before the New Testament publishes the Christ-interface. | bridge_declared | Reject if the two phases are collapsed into one undifferentiated claim. |
| POF2828-007 | christ-interface | The Johannine I AM statements function as interface declarations. | bridge_declared | Reject if they are only decorative metaphors with no access role. |
| POF2828-008 | christ-interface | Bread of life names divine sustenance as a creature-facing interface. | textual_structural_claim | Reject if bread is treated as interchangeable with other I AM roles. |
| POF2828-009 | christ-interface | Light of the world names revelation/intelligibility as a creature-facing interface. | textual_structural_claim | Reject if light is treated as merely emotional inspiration. |
| POF2828-010 | christ-interface | Door names access into divine presence as a creature-facing interface. | textual_structural_claim | Reject if access is detached from mediation. |
| POF2828-011 | christ-interface | Good shepherd names guidance and protection as a creature-facing interface. | textual_structural_claim | Reject if guidance and protection are not structurally distinct from sustenance. |
| POF2828-012 | christ-interface | Resurrection and life names death-defeat as a creature-facing interface. | textual_structural_claim | Reject if resurrection is reduced to moral inspiration. |
| POF2828-013 | christ-interface | Way, truth, and life unite path, reality, and vitality in one Christ-interface. | textual_structural_claim | Reject if way/truth/life can be separated without loss. |
| POF2828-014 | christ-interface | True vine names source-union and fruitfulness as a creature-facing interface. | textual_structural_claim | Reject if fruitfulness is modeled without continuing source-union. |
| POF2828-015 | interface-irreducibility | Bread, light, door, shepherd, resurrection, way/truth/life, and vine are irreducible roles rather than synonyms. | framework_guardrail | Reject if one role can replace every other role without remainder. |
| POF2828-016 | fulfillment | The New Testament I AM declarations fulfill rather than replace the Old Testament identity declarations. | bridge_declared | Reject if fulfillment erases Old Testament identity and authority. |
| POF2828-017 | typology | Manna maps to bread of life through received sustenance from above. | textual_structural_claim | Reject if the preserved structure is not sustenance. |
| POF2828-018 | typology | Pillar of fire maps to light of the world through divine illumination and guidance. | textual_structural_claim | Reject if the preserved structure is not illumination/guidance. |
| POF2828-019 | typology | Tabernacle door maps to I am the door through mediated entry into holy presence. | textual_structural_claim | Reject if entry is unmediated. |
| POF2828-020 | typology | Psalm 23 shepherd maps to good shepherd through personal guidance and protection. | textual_structural_claim | Reject if shepherding is not personal or protective. |
| POF2828-021 | typology | Passover lamb maps to resurrection and life through life preserved by given life. | textual_structural_claim | Reject if substitution/given-life structure is absent. |
| POF2828-022 | typology | Red Sea passage maps to the way through a path opened where creatures could not open one. | textual_structural_claim | Reject if the path is creature-generated. |
| POF2828-023 | typology | Tree of life / vine imagery maps to true vine through life by union with source. | textual_structural_claim | Reject if life is modeled apart from source-union. |
| POF2828-024 | typology | The words change across testaments while the preserved structure remains stable. | framework_guardrail | Reject if vocabulary continuity is required instead of structural continuity. |
| POF2828-025 | typology | Old Testament narrative types can be read as constants running before direct axiom naming. | bridge_declared | Reject if typology is treated as proof without structural preservation. |
| POF2828-026 | derivation-grammar | DG1 distinguishes root claims by absence of deeper predicate or external source. | framework_guardrail | Reject if the root claim depends on a lower explanatory layer. |
| POF2828-027 | derivation-grammar | I AM WHO I AM satisfies the DG1 root-layer signature. | framework_guardrail | Reject if the name is interpreted as caused by a prior layer. |
| POF2828-028 | derivation-grammar | DG8 filters denial by asking whether denial depends on the thing denied. | framework_guardrail | Reject if denial can borrow the denied condition without consequence. |
| POF2828-029 | adversarial-test | Ordinary power claims such as king/general fail the DG8 root-dependency test. | adversarial_test_candidate | Reject if political authority becomes structurally necessary to deny political authority. |
| POF2828-030 | truth-ontology | Denial of "I am the truth" still depends on truth conditions. | framework_guardrail | Reject if meaningful denial can avoid truth conditions entirely. |
| POF2828-031 | life-consciousness | Denial of "I am the life" is made by a living conscious agent. | framework_guardrail | Reject if the denial can be made without life or agency. |
| POF2828-032 | intelligibility | Denial of "I am the light" depends on intelligibility. | framework_guardrail | Reject if denial can be meaningful without intelligibility. |
| POF2828-033 | layer-zero-signature | A Layer 0 signature appears when a claim names a condition its denial must borrow. | framework_guardrail | Reject if borrowing is merely rhetorical and not structurally required. |
| POF2828-034 | freedom-response | Closure structure exposes dependency but does not mechanically force faith. | framework_guardrail | Reject if formal grammar is treated as coercive salvation. |

## Promotion Discipline

Before promotion, each candidate should receive:

1. Exact source anchor.
2. Ledger domain and canonical atom ID.
3. Claim class and proof label.
4. Dependencies.
5. Five negative guards or countertests for major theorem families.
6. Scope limits that prevent overclaiming.

